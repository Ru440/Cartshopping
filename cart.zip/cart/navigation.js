function goToPage(pageUrl) {
    // Add logic to navigate to the specified page URL
    window.location.href = pageUrl;
}
